let menu = document.querySelector('nav ul');
let menuIcon = document.querySelector('.menu-icon');

function abrirMenu(){
    document.querySelector('nav ul').classList.toggle('open');
}